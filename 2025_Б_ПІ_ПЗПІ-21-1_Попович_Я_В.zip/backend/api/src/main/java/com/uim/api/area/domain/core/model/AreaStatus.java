package com.uim.api.area.domain.core.model;

public enum AreaStatus {
    CREATED,
    AREA_SELECTED,
    REPORTED
}
