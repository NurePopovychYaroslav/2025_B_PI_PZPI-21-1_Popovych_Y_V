package com.uim.api.report.domain.core.model;

public enum ReportStatus {
    CREATED,
    LAYERED,
    PENDING,
    AREAED,
    FORMED
}
