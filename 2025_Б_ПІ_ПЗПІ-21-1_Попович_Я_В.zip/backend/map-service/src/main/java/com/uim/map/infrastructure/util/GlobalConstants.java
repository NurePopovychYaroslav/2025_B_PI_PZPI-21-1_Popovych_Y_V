package com.uim.map.infrastructure.util;

public class GlobalConstants {

    public static final String INVALID = "invalid_";
    public static final String VALIDATION_FAILED = "validation_failed";

}
