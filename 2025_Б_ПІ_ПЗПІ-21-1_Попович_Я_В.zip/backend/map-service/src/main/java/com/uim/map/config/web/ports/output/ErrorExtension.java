package com.uim.map.config.web.ports.output;

public record ErrorExtension(String errorMessage, String errorCode) {
}
