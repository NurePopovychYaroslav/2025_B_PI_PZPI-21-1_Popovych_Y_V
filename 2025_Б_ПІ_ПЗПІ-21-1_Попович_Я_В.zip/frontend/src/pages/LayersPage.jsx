import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import AreaMap from "../components/AreaMap";

export default function LayersPage() {
    const navigate = useNavigate();
    const [layers, setLayers] = useState([]);
    const [selectedLayers, setSelectedLayers] = useState([]);
    const [isSelecting, setIsSelecting] = useState(false);
    const [newLayer, setNewLayer] = useState({
        name: '',
        description: '',
        intensity: '',
    });
    const drawnItemsRef = useRef(null);

    const handleStartSelection = () => {
        setIsSelecting(true);
    };

    const handleSaveLayer = async () => {
        const layer = drawnItemsRef.current.getLayers()[0];
        if (!layer) {
            alert('Будь ласка, оберіть полігон на мапі.');
            return;
        }

        const latlngs = layer.getLatLngs()[0];
        const coordinates = latlngs.map((point) => ({
            x: point.lng,
            y: point.lat,
        }));

        try {
            const response = await fetch("http://localhost:18081/map/api/v1/layers", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name: newLayer.name,
                    description: newLayer.description,
                    coordinates: coordinates,
                    intensity: parseFloat(newLayer.intensity),
                }),
            });
            const data = await response.json();
            navigate(`/layers/${data.self}`);
        } catch (error) {
            console.error("Помилка створення шару:", error);
        }
    };

    const handleCheckboxChange = (layer) => {
        setSelectedLayers((prev) => {
            const exists = prev.find(l => l.self === layer.self);
            if (exists) {
                return prev.filter(l => l.self !== layer.self);
            } else {
                return [...prev, layer];
            }
        });
    };

    useEffect(() => {
        async function fetchLayers() {
            try {
                const response = await fetch("http://localhost:18081/map/api/v1/layers");
                const data = await response.json();
                setLayers(data);
            } catch (error) {
                console.error("Помилка завантаження списку шарів:", error);
            }
        }
        fetchLayers();
    }, []);

    return (
        <div className="flex h-[calc(100vh-80px)]">
            <AreaMap polygons={selectedLayers} isSelecting={isSelecting} drawnItemsRef={drawnItemsRef} type="layer" />
            <div className="basis-1/3 h-full bg-gray-100 p-4 space-y-4 overflow-auto">
                <div className="flex flex-col items-center space-y-4">
                    {!isSelecting && (
                        <button
                            onClick={handleStartSelection}
                            className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                            Обрати шар
                        </button>
                    )}
                    {isSelecting && (
                        <div className="w-full space-y-4">
                            <input
                                type="text"
                                placeholder="Назва шару"
                                className="w-full p-2 border rounded"
                                value={newLayer.name}
                                onChange={(e) => setNewLayer({ ...newLayer, name: e.target.value })}
                            />
                            <input
                                type="text"
                                placeholder="Опис шару"
                                className="w-full p-2 border rounded"
                                value={newLayer.description}
                                onChange={(e) => setNewLayer({ ...newLayer, description: e.target.value })}
                            />
                            <input
                                type="number"
                                step="0.01"
                                min="0"
                                max="1"
                                placeholder="Інтенсивність (0-1)"
                                className="w-full p-2 border rounded"
                                value={newLayer.intensity}
                                onChange={(e) => setNewLayer({ ...newLayer, intensity: e.target.value })}
                            />
                            <button
                                onClick={handleSaveLayer}
                                className="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
                            >
                                Зберегти шар
                            </button>
                        </div>
                    )}
                </div>
                <div className="w-full">
                    <h2 className="text-lg font-bold mb-2">Список шарів</h2>
                    <ul className="space-y-2">
                        {layers.map((layer) => (
                            <li key={layer.self} className="flex items-center space-x-2">
                                <input
                                    type="checkbox"
                                    id={layer.self}
                                    onChange={() => handleCheckboxChange(layer)}
                                    checked={selectedLayers.some(l => l.self === layer.self)}
                                />
                                <Link
                                    to={`/layers/${layer.self}`}
                                    className="text-sm text-blue-600 hover:underline"
                                >
                                    {layer.name}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
}