import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import AreaMap from "../components/AreaMap";

export default function ReportPage() {
    const { reportId } = useParams();
    const [areas, setAreas] = useState([]);
    const [allLayers, setAllLayers] = useState([]);
    const [selectedLayers, setSelectedLayers] = useState([]);
    const [reportStatus, setReportStatus] = useState(null);
    const [reportUrl, setReportUrl] = useState(null);
    const [loading, setLoading] = useState(true);
    const drawnItemsRef = useRef(null);

    useEffect(() => {
        fetchReportAndLayers();
    }, [reportId]);

    useEffect(() => {
        let intervalId;

        if (reportStatus === "PENDING") {
            intervalId = setInterval(() => {
                console.log("Автооновлення звіту...");
                fetchReportAndLayers();
            }, 5000); // кожні 5 секунд
        }

        return () => {
            if (intervalId) {
                clearInterval(intervalId);
            }
        };
    }, [reportStatus]);

    const fetchReportAndLayers = async () => {
        setLoading(true);
        try {
            const reportResponse = await fetch(`http://localhost:18081/map/api/v1/report/${reportId}`);
            const reportData = await reportResponse.json();

            setReportStatus(reportData.status);
            setReportUrl(reportData.url || null);

            const loadedAreas = await Promise.all(
                reportData.areas.map(async (area) => {
                    const areaResponse = await fetch(`http://localhost:18081/map/api/v1/area/${area.code}`);
                    const areaData = await areaResponse.json();
                    return {
                        self: areaData.self,
                        coordinates: areaData.coordinates || [],
                    };
                })
            );
            setAreas(loadedAreas);

            const layersResponse = await fetch("http://localhost:18081/map/api/v1/layers");
            const layersData = await layersResponse.json();
            setAllLayers(layersData);

            if (reportData.layers && reportData.layers.length > 0) {
                const loadedReportLayers = await Promise.all(
                    reportData.layers.map(async (layer) => {
                        const layerResponse = await fetch(`http://localhost:18081/map/api/v1/layers/${layer.code}`);
                        const layerData = await layerResponse.json();
                        return {
                            self: layerData.self,
                            coordinates: layerData.coordinates || [],
                            name: layerData.name,
                        };
                    })
                );
                setSelectedLayers(loadedReportLayers);
            }
        } catch (error) {
            console.error("Помилка завантаження даних:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleLayerCheckboxChange = (layer) => {
        setSelectedLayers((prev) => {
            const exists = prev.find(l => l.self === layer.self);
            if (exists) {
                return prev.filter(l => l.self !== layer.self);
            } else {
                return [...prev, layer];
            }
        });
    };

    const handleAddLayersToReport = async () => {
        setLoading(true);
        try {
            await fetch(`http://localhost:18081/map/api/v1/report/${reportId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    areas: areas.map(area => ({ code: area.self })),
                    layers: selectedLayers.map(layer => ({ code: layer.self })),
                }),
            });
            await fetchReportAndLayers();
            alert("Шари успішно додано до звіту!");
        } catch (error) {
            console.error("Помилка при додаванні шарів:", error);
            alert("Не вдалося додати шари.");
        } finally {
            setLoading(false);
        }
    };

    const handleInitiateReport = async () => {
        setLoading(true);
        try {
            await fetch(`http://localhost:18081/map/api/v1/report/${reportId}/initiate`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: "ONE_PAGE" }),
            });
            await fetchReportAndLayers();
            alert("Формування звіту розпочато!");
        } catch (error) {
            console.error("Помилка при ініціації звіту:", error);
            alert("Не вдалося ініціювати формування звіту.");
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <>
                <div className="fixed top-0 left-0 w-full h-1 bg-blue-600 animate-pulse z-50"></div>
                <div className="flex items-center justify-center h-screen">
                    Завантаження...
                </div>
            </>
        );
    }

    return (
        <div className="flex h-[calc(100vh-80px)]">
            {/* Мапа */}
            <div className="basis-2/3 h-full">
                <AreaMap
                    polygons={areas}
                    drawnItemsRef={drawnItemsRef}
                    polygonsForLayers={selectedLayers}
                />
            </div>

            {/* Права панель */}
            <div className="basis-1/3 bg-gray-100 p-4 flex flex-col space-y-4 overflow-auto">
                <h2 className="text-xl font-bold mb-2">Звіт {reportId}</h2>
                <h3 className="text-lg font-semibold mb-2">Статус: {reportStatus}</h3>

                {reportStatus !== "FORMED" && (
                    <>
                        <h3 className="text-lg font-semibold mb-2">Доступні шари</h3>
                        <ul className="space-y-2">
                            {allLayers.map((layer) => (
                                <li key={layer.self} className="flex items-center space-x-2">
                                    <input
                                        type="checkbox"
                                        id={layer.self}
                                        onChange={() => handleLayerCheckboxChange(layer)}
                                        checked={selectedLayers.some(l => l.self === layer.self)}
                                        disabled={reportStatus === "PENDING"}
                                    />
                                    <label htmlFor={layer.self} className="text-sm">{layer.name}</label>
                                </li>
                            ))}
                        </ul>

                        {/* Кнопка додати шари */}
                        {selectedLayers.length > 0 && (
                            <button
                                onClick={handleAddLayersToReport}
                                disabled={reportStatus === "PENDING" || loading}
                                className={`w-full px-6 py-3 rounded-lg text-white ${
                                    reportStatus === "PENDING" || loading
                                        ? "bg-gray-400 cursor-not-allowed"
                                        : "bg-green-600 hover:bg-green-700"
                                }`}
                            >
                                Додати обрані шари
                            </button>
                        )}
                    </>
                )}

                {/* Кнопка сформувати звіт */}
                {(reportStatus === "LAYERED" || reportStatus === "PENDING") && (
                    <button
                        onClick={handleInitiateReport}
                        disabled={loading}
                        className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                        Сформувати звіт
                    </button>
                )}

                {/* Кнопка скачати PDF */}
                {reportStatus === "FORMED" && reportUrl && (
                    <a
                        href={reportUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full px-6 py-3 text-center bg-green-600 text-white rounded-lg hover:bg-green-700"
                    >
                        Завантажити звіт
                    </a>
                )}
            </div>
        </div>
    );
}