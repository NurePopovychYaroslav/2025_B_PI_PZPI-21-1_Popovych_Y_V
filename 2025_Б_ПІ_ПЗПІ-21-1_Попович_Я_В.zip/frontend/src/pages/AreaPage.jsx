import { useState, useEffect, useRef } from "react";
import {useNavigate, useParams} from "react-router-dom";
import AreaMap from "../components/AreaMap.jsx";
import ControlPanel from "../components/ControlPanel";

export default function AreaPage() {
    const { areaId } = useParams();
    const [coordinates, setCoordinates] = useState([]);
    const [isSelecting, setIsSelecting] = useState(false);
    const [showConfirmButton, setShowConfirmButton] = useState(false);
    const drawnItemsRef = useRef(null);
    const navigate = useNavigate();

    useEffect(() => {
        async function fetchArea() {
            try {
                const response = await fetch(`http://localhost:18081/map/api/v1/area/${areaId}`);
                const data = await response.json();
                if (data.coordinates) {
                    setCoordinates(data.coordinates);
                }
                setIsSelecting(true);
                setShowConfirmButton(true);
            } catch (error) {
                console.error("Помилка завантаження ділянки:", error);
            }
        }
        fetchArea();
    }, [areaId]);

    const handleConfirmSelection = async () => {
        const layer = drawnItemsRef.current.getLayers()[0];
        if (!layer) return;

        const latlngs = layer.getLatLngs()[0];

        const cords = latlngs.map((point) => ({
            x: point.lng,
            y: point.lat,
        }));

        try {
            await fetch(`http://localhost:18081/map/api/v1/area/${areaId}/select-area`, {
                method: "PATCH",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ cords }),
            });
            alert("Зона успішно вибрана!");
            navigate(`/map`);
        } catch (error) {
            console.error("Помилка при виборі ділянки:", error);
        }
    };

    return (
        <div className="flex h-[calc(100vh-80px)]">
            <div className="basis-2/3 h-full">
                <AreaMap
                    isSelecting={isSelecting}
                    drawnItemsRef={drawnItemsRef}
                    initialCoordinates={coordinates}
                />
            </div>
            <div className="basis-1/3 h-full bg-gray-100 p-4 flex flex-col space-y-4 overflow-auto">
                <ControlPanel
                    isSelecting={isSelecting}
                    showConfirmButton={showConfirmButton}
                    onStartSelection={() => {}}
                    onConfirmSelection={handleConfirmSelection}
                />
            </div>
        </div>
    );
}