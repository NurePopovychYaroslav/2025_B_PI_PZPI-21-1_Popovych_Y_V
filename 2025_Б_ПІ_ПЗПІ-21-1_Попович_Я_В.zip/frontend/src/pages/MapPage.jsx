import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import AreaMap from "../components/AreaMap";
import ControlPanel from "../components/ControlPanel";

export default function MapPage() {
    const navigate = useNavigate();
    const [areas, setAreas] = useState([]);
    const [selectedAreas, setSelectedAreas] = useState([]);

    const handleStartSelection = async () => {
        try {
            const response = await fetch("http://localhost:18081/map/api/v1/area", { method: "POST" });
            const data = await response.json();
            navigate(`/map/${data.self}`);
        } catch (error) {
            console.error("Помилка створення ділянки:", error);
        }
    };

    const handleCheckboxChange = (area) => {
        setSelectedAreas((prevSelected) => {
            const exists = prevSelected.find(a => a.self === area.self);
            if (exists) {
                return prevSelected.filter(a => a.self !== area.self);
            } else {
                return [...prevSelected, area];
            }
        });
    };

    const handleCreateReport = async () => {
        try {
            const response = await fetch("http://localhost:18081/map/api/v1/report", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    areas: selectedAreas.map(area => ({ code: area.self })),
                }),
            });
            const data = await response.json();
            navigate(`/reports/${data.self}`);
        } catch (error) {
            console.error("Помилка створення звіту:", error);
        }
    };

    useEffect(() => {
        async function fetchAreas() {
            try {
                const response = await fetch("http://localhost:18081/map/api/v1/area");
                const data = await response.json();
                setAreas(data);
            } catch (error) {
                console.error("Помилка завантаження списку зон:", error);
            }
        }
        fetchAreas();
    }, []);

    return (
        <div className="flex h-[calc(100vh-80px)]">
            <AreaMap polygons={selectedAreas} />
            <div className="basis-1/3 h-full bg-gray-100 flex flex-col p-4 space-y-4 overflow-auto">
                <div className="flex flex-col items-center space-y-4">
                    <button
                        onClick={handleStartSelection}
                        className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                        Обрати зону
                    </button>
                    {selectedAreas.length > 0 && (
                        <button
                            onClick={handleCreateReport}
                            className="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
                        >
                            Створити звіт
                        </button>
                    )}
                </div>
                <div className="w-full">
                    <h2 className="text-lg font-bold mb-2">Список зон</h2>
                    <ul className="space-y-2">
                        {areas.map((area) => (
                            <li key={area.self} className="flex items-center space-x-2">
                                <input
                                    type="checkbox"
                                    id={area.self}
                                    onChange={() => handleCheckboxChange(area)}
                                    checked={selectedAreas.some(a => a.self === area.self)}
                                    disabled={!area.coordinates || area.coordinates.length === 0}
                                />
                                <Link
                                    to={`/map/${area.self}`}
                                    className="text-sm text-blue-600 hover:underline"
                                >
                                    {area.self} ({area.status})
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
}