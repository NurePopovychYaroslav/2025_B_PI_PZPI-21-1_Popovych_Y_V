import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function ReportsPage() {
    const [reports, setReports] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        async function fetchReports() {
            try {
                const response = await fetch("http://localhost:18081/map/api/v1/report");
                const data = await response.json();
                setReports(data);
            } catch (error) {
                console.error("Помилка завантаження списку звітів:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchReports();
    }, []);

    if (loading) {
        return <div className="flex items-center justify-center h-screen">Завантаження списку звітів...</div>;
    }

    return (
        <div className="flex flex-col items-center p-8 space-y-4">
            <h1 className="text-2xl font-bold">Список звітів</h1>
            <ul className="w-full max-w-3xl space-y-3">
                {reports.map((report) => (
                    <li
                        key={report.self}
                        onClick={() => navigate(`/reports/${report.self}`)}
                        className="cursor-pointer p-4 border rounded-md hover:bg-gray-100 transition"
                    >
                        <div className="flex justify-between items-center">
                            <span>Звіт: {report.self}</span>
                            <span className={`text-sm ${report.status === "FORMED" ? "text-green-600" : "text-yellow-600"}`}>
                {report.status}
              </span>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}