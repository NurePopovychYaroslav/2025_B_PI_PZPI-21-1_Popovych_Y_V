export default function ProfilePage() {
    return (
        <div className="p-4 text-2xl">
            👤 Це сторінка профілю користувача (ProfilePage)
        </div>
    );
}