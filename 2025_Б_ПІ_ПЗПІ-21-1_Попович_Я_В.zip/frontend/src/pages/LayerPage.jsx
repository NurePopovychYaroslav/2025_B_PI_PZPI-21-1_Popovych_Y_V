import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import AreaMap from "../components/AreaMap";

export default function LayerPage() {
    const { layerId } = useParams();
    const [layer, setLayer] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function fetchLayer() {
            try {
                const response = await fetch(`http://localhost:18081/map/api/v1/layers/${layerId}`);
                const data = await response.json();
                setLayer(data);
            } catch (error) {
                console.error("Помилка завантаження шару:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchLayer();
    }, [layerId]);

    if (loading) {
        return <div className="flex items-center justify-center h-screen">Завантаження шару...</div>;
    }

    return (
        <div className="flex h-[calc(100vh-80px)]">
            <AreaMap polygons={[layer]} />
            <div className="basis-1/3 bg-gray-100 p-4 flex flex-col">
                <h2 className="text-xl font-bold mb-2">{layer.name}</h2>
                <p className="text-gray-700 mb-2">{layer.description}</p>
                <p className="text-gray-500">Інтенсивність: {layer.intensity}</p>
            </div>
        </div>
    );
}