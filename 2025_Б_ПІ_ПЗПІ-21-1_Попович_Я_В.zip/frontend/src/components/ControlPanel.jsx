import PropTypes from "prop-types";

export default function ControlPanel({ isSelecting, showConfirmButton, onStartSelection, onConfirmSelection }) {
    return (
        <div className="w-full flex flex-col items-center justify-start space-y-4">
            {!isSelecting && (
                <button
                    onClick={onStartSelection}
                    className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                    Обрати зону
                </button>
            )}
            {showConfirmButton && (
                <button
                    onClick={onConfirmSelection}
                    className="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                    Обрати
                </button>
            )}
        </div>
    );
}

ControlPanel.propTypes = {
    isSelecting: PropTypes.bool.isRequired,
    showConfirmButton: PropTypes.bool.isRequired,
    onStartSelection: PropTypes.func.isRequired,
    onConfirmSelection: PropTypes.func.isRequired,
};