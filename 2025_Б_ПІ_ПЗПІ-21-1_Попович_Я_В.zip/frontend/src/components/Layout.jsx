import {Link, Outlet} from "react-router-dom";

export default function Layout() {
    return (
        <div className="min-h-screen flex flex-col">
            <header className="bg-blue-600 text-white p-4 flex space-x-6">
                <Link to="/map" className="hover:underline">Карта</Link>
                <Link to="/reports" className="hover:underline">Звіти</Link>
                <Link to="/profile" className="hover:underline">Профіль</Link>
                <Link to="/layers" className="hover:underline">Шари</Link>
            </header>
            <main className="flex-1 p-4">
                <Outlet />
            </main>
        </div>
    );
}