import {EditControl} from "react-leaflet-draw";
import {FeatureGroup, MapContainer, Polygon, TileLayer} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";

export default function AreaMap({ polygons = [], initialCoordinates = [], polygonsForLayers = [], isSelecting = false, drawnItemsRef, type = "area" }) {
    const areasToDraw = polygons.length > 0 ? polygons : (initialCoordinates.length > 0 ? [{ coordinates: initialCoordinates }] : []);

    return (
        <div className="w-full h-full">
            <MapContainer
                center={[48.3794, 31.1656]}
                zoom={6}
                scrollWheelZoom={true}
                className="w-full h-full"
            >
                <TileLayer
                    attribution='&copy; <a href="https://www.maptiler.com/">MapTiler</a> contributors'
                    url={`https://api.maptiler.com/maps/streets/{z}/{x}/{y}.png?key=${import.meta.env.VITE_MAPTILER_API_KEY}&language=uk`}
                    tileSize={512}
                    zoomOffset={-1}
                />
                <FeatureGroup ref={drawnItemsRef}>
                    {/* Малюємо сині ділянки (areas) */}
                    {areasToDraw.map((area, idx) =>
                        area.coordinates ? (
                            <Polygon
                                key={area.self || idx}
                                positions={area.coordinates.map(({ y, x }) => [y, x])}
                                pathOptions={{ color: "blue" }}
                            />
                        ) : null
                    )}
                    {/* Малюємо помаранчеві шари (layers) */}
                    {polygonsForLayers.map((layer, idx) =>
                        layer.coordinates ? (
                            <Polygon
                                key={layer.self || `layer-${idx}`}
                                positions={layer.coordinates.map(({ y, x }) => [y, x])}
                                pathOptions={{ color: "orange" }}
                            />
                        ) : null
                    )}
                    {/* Малювання нової області */}
                    {isSelecting && (
                        <EditControl
                            position="topright"
                            draw={{
                                polygon: true,
                                rectangle: false,
                                circle: false,
                                circlemarker: false,
                                polyline: false,
                                marker: false,
                            }}
                        />
                    )}
                </FeatureGroup>
            </MapContainer>
        </div>
    );
}