import {createBrowserRouter, Link, Route, Router, RouterProvider, Routes} from "react-router-dom";
import MapPage from "./pages/MapPage.jsx";
import ReportsPage from "./pages/ReportsPage.jsx";
import ProfilePage from "./pages/ProfilePage.jsx";
import Layout from "./components/Layout.jsx";
import AreaPage from "./pages/AreaPage.jsx";
import ReportPage from "./pages/ReportPage.jsx";
import LayersPage from "./pages/LayersPage.jsx";
import LayerPage from "./pages/LayerPage.jsx";

const router = createBrowserRouter([
    {
        path: "/",
        element: <Layout />,
        children: [
            { path: "map", element: <MapPage /> },
            { path: "map/:areaId", element: <AreaPage /> },
            { path: "reports", element: <ReportsPage /> },
            { path: "reports/:reportId", element: <ReportPage /> },
            { path: "profile", element: <ProfilePage /> },
            { path: "layers", element: <LayersPage /> },
            { path: "layers/:layerId", element: <LayerPage /> },
        ],
    },
]);
export default function App() {
    return <RouterProvider router={router} />;
}